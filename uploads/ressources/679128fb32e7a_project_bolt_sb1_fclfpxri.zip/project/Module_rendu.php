<?php
require_once 'controleur_rendu.php';

class Module_rendu {
    private $controleur;
    
    public function __construct() {
        $this->controleur = new Controleur_rendu();
    }
    
    public function execute($action) {
        switch ($action) {
            case 'submit':
                $this->controleur->soumettreRendu();
                break;
            case 'list':
                $this->controleur->listerRendus();
                break;
            case 'evaluate':
                $this->controleur->evaluerRendu();
                break;
            case 'download':
                $this->controleur->telechargerRendu();
                break;
            default:
                // Redirection vers la page d'accueil ou affichage d'une erreur
                header('Location: index.php');
                exit;
        }
    }
}