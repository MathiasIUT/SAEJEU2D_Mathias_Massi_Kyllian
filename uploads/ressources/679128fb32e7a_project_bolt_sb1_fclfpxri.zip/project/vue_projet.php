<?php
require_once ROOT_PATH . '/core/View.php';

class Vue_projet extends View {
    public function afficherFormulaire($data = []) {
        $this->render('projet/formulaire', $data);
    }
    
    public function afficherListe($data) {
        $this->render('projet/liste', $data);
    }
    
    public function afficherDetails($data) {
        $this->render('projet/details', $data);
    }
}