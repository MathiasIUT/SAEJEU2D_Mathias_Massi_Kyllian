<?php
require_once 'modele_evaluation.php';
require_once 'vue_evaluation.php';

class Controleur_evaluation {
    private $modele;
    private $vue;
    
    public function __construct() {
        $this->modele = new Modele_evaluation();
        $this->vue = new Vue_evaluation();
    }
    
    public function creerEvaluation() {
        // Vérifier que l'utilisateur est un enseignant ou admin
        if (!isset($_SESSION['user']) || ($_SESSION['user']['role'] !== 'enseignant' && $_SESSION['user']['role'] !== 'admin')) {
            $_SESSION['flash'] = [
                'type' => 'danger',
                'message' => 'Accès non autorisé'
            ];
            header('Location: index.php');
            exit;
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $id_projet = $_POST['id_projet'] ?? 0;
            $titre = $_POST['titre'] ?? '';
            $description = $_POST['description'] ?? '';
            $coefficient = $_POST['coefficient'] ?? 1;
            $type = $_POST['type'] ?? 'groupe'; // groupe ou individuel
            $id_rendu = $_POST['id_rendu'] ?? null;
            
            // Validation
            if (empty($titre) || empty($id_projet)) {
                $this->vue->afficherFormulaire([
                    'error' => 'Veuillez remplir tous les champs obligatoires',
                    'projets' => $this->modele->getProjetsEnseignant($_SESSION['user']['id'])
                ]);
                return;
            }
            
            // Création de l'évaluation
            if ($this->modele->creerEvaluation($id_projet, $titre, $description, $coefficient, $type, $id_rendu)) {
                $_SESSION['flash'] = [
                    'type' => 'success',
                    'message' => 'Évaluation créée avec succès'
                ];
                header('Location: index.php?module=evaluation&action=list');
                exit;
            }
            
            $this->vue->afficherFormulaire([
                'error' => 'Erreur lors de la création de l\'évaluation',
                'projets' => $this->modele->getProjetsEnseignant($_SESSION['user']['id'])
            ]);
        } else {
            $this->vue->afficherFormulaire([
                'projets' => $this->modele->getProjetsEnseignant($_SESSION['user']['id'])
            ]);
        }
    }
    
    public function deleguerEvaluation() {
        if (!isset($_SESSION['user']) || ($_SESSION['user']['role'] !== 'enseignant' && $_SESSION['user']['role'] !== 'admin')) {
            $_SESSION['flash'] = [
                'type' => 'danger',
                'message' => 'Accès non autorisé'
            ];
            header('Location: index.php');
            exit;
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $id_evaluation = $_POST['id_evaluation'] ?? 0;
            $id_enseignant = $_POST['id_enseignant'] ?? 0;
            
            if (empty($id_evaluation) || empty($id_enseignant)) {
                $_SESSION['flash'] = [
                    'type' => 'danger',
                    'message' => 'Paramètres invalides'
                ];
                header('Location: index.php?module=evaluation&action=list');
                exit;
            }
            
            if ($this->modele->deleguerEvaluation($id_evaluation, $id_enseignant)) {
                $_SESSION['flash'] = [
                    'type' => 'success',
                    'message' => 'Évaluation déléguée avec succès'
                ];
            } else {
                $_SESSION['flash'] = [
                    'type' => 'danger',
                    'message' => 'Erreur lors de la délégation'
                ];
            }
            header('Location: index.php?module=evaluation&action=list');
            exit;
        }
        
        $id_evaluation = $_GET['id'] ?? 0;
        $evaluation = $this->modele->getEvaluationById($id_evaluation);
        
        if (!$evaluation) {
            $_SESSION['flash'] = [
                'type' => 'danger',
                'message' => 'Évaluation introuvable'
            ];
            header('Location: index.php?module=evaluation&action=list');
            exit;
        }
        
        $this->vue->afficherDelegation([
            'evaluation' => $evaluation,
            'enseignants' => $this->modele->getEnseignantsDisponibles($id_evaluation)
        ]);
    }
    
    public function listerEvaluations() {
        if (!isset($_SESSION['user'])) {
            $_SESSION['flash'] = [
                'type' => 'danger',
                'message' => 'Vous devez être connecté'
            ];
            header('Location: index.php?module=auth&action=login');
            exit;
        }

        $evaluations = [];
        if ($_SESSION['user']['role'] === 'enseignant' || $_SESSION['user']['role'] === 'admin') {
            $evaluations = $this->modele->getEvaluationsEnseignant($_SESSION['user']['id']);
        } else {
            $evaluations = $this->modele->getEvaluationsEtudiant($_SESSION['user']['id']);
        }
        
        $this->vue->afficherListe(['evaluations' => $evaluations]);
    }
}