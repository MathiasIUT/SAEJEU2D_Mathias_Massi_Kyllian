<?php
require_once ROOT_PATH . '/core/Model.php';

class Modele_evaluation extends Model {
    public function creerEvaluation($id_projet, $titre, $description, $coefficient, $type, $id_rendu = null) {
        $query = $this->db->prepare('
            INSERT INTO evaluation (id_projet, titre, description, coefficient, type, id_rendu) 
            VALUES (?, ?, ?, ?, ?, ?)
        ');
        return $query->execute([$id_projet, $titre, $description, $coefficient, $type, $id_rendu]);
    }
    
    public function deleguerEvaluation($id_evaluation, $id_enseignant) {
        $query = $this->db->prepare('
            UPDATE evaluation 
            SET id_enseignant_delegue = ? 
            WHERE id_evaluation = ?
        ');
        return $query->execute([$id_enseignant, $id_evaluation]);
    }
    
    public function getEvaluationsEnseignant($id_enseignant) {
        $query = $this->db->prepare('
            SELECT e.*, p.titre as projet_titre
            FROM evaluation e
            JOIN projet p ON e.id_projet = p.id_projet
            LEFT JOIN projet_responsable pr ON p.id_projet = pr.id_projet
            WHERE pr.id_enseignant = ? OR e.id_enseignant_delegue = ?
            ORDER BY e.date_creation DESC
        ');
        $query->execute([$id_enseignant, $id_enseignant]);
        return $query->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public function getEvaluationsEtudiant($id_etudiant) {
        $query = $this->db->prepare('
            SELECT e.*, p.titre as projet_titre
            FROM evaluation e
            JOIN projet p ON e.id_projet = p.id_projet
            JOIN groupe_projet gp ON p.id_projet = gp.id_projet
            JOIN groupe_etudiant ge ON gp.id_groupe = ge.id_groupe
            WHERE ge.id_etudiant = ?
            ORDER BY e.date_creation DESC
        ');
        $query->execute([$id_etudiant]);
        return $query->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public function getProjetsEnseignant($id_enseignant) {
        $query = $this->db->prepare('
            SELECT DISTINCT p.*
            FROM projet p
            JOIN projet_responsable pr ON p.id_projet = pr.id_projet
            WHERE pr.id_enseignant = ?
            ORDER BY p.date_creation DESC
        ');
        $query->execute([$id_enseignant]);
        return $query->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public function getEnseignantsDisponibles($id_evaluation) {
        $query = $this->db->prepare('
            SELECT u.*
            FROM utilisateurs u
            WHERE u.role = "enseignant"
            ORDER BY u.nom, u.prenom
        ');
        $query->execute();
        return $query->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public function getEvaluationById($id_evaluation) {
        $query = $this->db->prepare('
            SELECT e.*, p.titre as projet_titre
            FROM evaluation e
            JOIN proj