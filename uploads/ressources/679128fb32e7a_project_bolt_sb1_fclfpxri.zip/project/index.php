<?php
session_start();
define('ROOT_PATH', __DIR__);

// Récupération du module et de l'action depuis l'URL
$module = $_GET['module'] ?? 'accueil';
$action = $_GET['action'] ?? 'index';

// Chargement du module approprié
switch ($module) {
    case 'ressource':
        require_once 'Module_ressource.php';
        $module_instance = new Module_ressource();
        break;
    // ... autres cas pour les autres modules ...
    default:
        header('Location: index.php?module=accueil');
        exit;
}

// Exécution de l'action
$module_instance->execute($action);