<?php
$error = $data['error'] ?? '';
?>
<div class="container mt-4">
    <div class="card">
        <div class="card-header">
            <h2>Ajouter une ressource</h2>
        </div>
        <div class="card-body">
            <?php if ($error): ?>
                <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>
            
            <form method="POST" action="index.php?module=ressource&action=add" enctype="multipart/form-data">
                <div class="form-group mb-3">
                    <label for="titre">Titre *</label>
                    <input type="text" class="form-control" id="titre" name="titre" required>
                </div>
                
                <div class="form-group mb-3">
                    <label for="description">Description</label>
                    <textarea class="form-control" id="description" name="description" rows="3"></textarea>
                </div>
                
                <div class="form-group mb-3">
                    <label for="type">Type de ressource *</label>
                    <select class="form-control" id="type" name="type" required>
                        <option value="">Sélectionner un type</option>
                        <option value="document">Document</option>
                        <option value="video">Vidéo</option>
                        <option value="lien">Lien</option>
                        <option value="autre">Autre</option>
                    </select>
                </div>
                
                <div class="form-group mb-3">
                    <label for="lien">Lien (optionnel)</label>
                    <input type="url" class="form-control" id="lien" name="lien">
                </div>
                
                <div class="form-group mb-3">
                    <label for="fichier">Fichier (optionnel)</label>
                    <input type="file" class="form-control" id="fichier" name="fichier">
                    <small class="form-text text-muted">
                        Formats acceptés : PDF, DOC, DOCX, TXT, ZIP, RAR
                    </small>
                </div>
                
                <button type="submit" class="btn btn-primary">Ajouter la ressource</button>
            </form>
        </div>
    </div>
</div>