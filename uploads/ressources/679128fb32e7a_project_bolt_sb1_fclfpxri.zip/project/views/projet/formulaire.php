<?php
$error = $data['error'] ?? '';
$etudiants = $data['etudiants'] ?? [];
?>
<div class="container mt-4">
    <div class="card">
        <div class="card-header">
            <h2>Créer un nouveau projet</h2>
        </div>
        <div class="card-body">
            <?php if ($error): ?>
                <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>
            
            <form method="POST" action="index.php?module=projet&action=create">
                <div class="form-group mb-3">
                    <label for="titre">Titre du projet *</label>
                    <input type="text" class="form-control" id="titre" name="titre" required>
                </div>
                
                <div class="form-group mb-3">
                    <label for="description">Description</label>
                    <textarea class="form-control" id="description" name="description" rows="3"></textarea>
                </div>
                
                <div class="form-group mb-3">
                    <label for="annee">Année universitaire *</label>
                    <input type="text" class="form-control" id="annee" name="annee" required>
                </div>
                
                <div class="form-group mb-3">
                    <label for="semestre">Semestre *</label>
                    <select class="form-control" id="semestre" name="semestre" required>
                        <option value="1">Semestre 1</option>
                        <option value="2">Semestre 2</option>
                    </select>
                </div>
                
                <div class="form-check mb-3">
                    <input type="checkbox" class="form-check-input" id="travail_groupe" name="travail_groupe">
                    <label class="form-check-label" for="travail_groupe">Travail en groupe</label>
                </div>
                
                <div class="form-check mb-3">
                    <input type="checkbox" class="form-check-input" id="groupe_modifiable" name="groupe_modifiable">
                    <label class="form-check-label" for="groupe_modifiable">Groupe modifiable par les étudiants</label>
                </div>
                
                <div id="section_groupe" style="display: none;">
                    <div class="form-group mb-3">
                        <label for="titre_groupe">Titre du groupe</label>
                        <input type="text" class="form-control" id="titre_groupe" name="titre_groupe">
                    </div>
                    
                    <div class="form-group mb-3">
                        <label>Sélectionner les étudiants</label>
                        <select class="form-control" name="etudiants[]" multiple>
                            <?php foreach ($etudiants as $etudiant): ?>
                                <option value="<?php echo $etudiant['id']; ?>">
                                    <?php echo htmlspecialchars($etudiant['nom'] . ' ' . $etudiant['prenom']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                
                <button type="submit" class="btn btn-primary">Créer le projet</button>
            </form>
        </div>
    </div>
</div>

<script>
document.getElementById('travail_groupe').addEventListener('change', function() {
    document.getElementById('section_groupe').style.display = this.checked ? 'block' : 'none';
});
</script>