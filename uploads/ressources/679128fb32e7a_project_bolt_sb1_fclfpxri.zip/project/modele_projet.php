<?php
require_once ROOT_PATH . '/core/Model.php';

class Modele_projet extends Model {
    public function creerProjet($titre, $description, $annee, $semestre, $travail_groupe, $groupe_modifiable, $id_enseignant) {
        try {
            $this->db->beginTransaction();
            
            // Création du projet
            $query = $this->db->prepare('
                INSERT INTO projet (titre, description, annee, semestre, travail_groupe, groupe_modifiable) 
                VALUES (?, ?, ?, ?, ?, ?)
            ');
            $query->execute([$titre, $description, $annee, $semestre, $travail_groupe, $groupe_modifiable]);
            $id_projet = $this->db->lastInsertId();
            
            // Ajout de l'enseignant comme responsable
            $query = $this->db->prepare('
                INSERT INTO projet_responsable (id_projet, id_enseignant, role) 
                VALUES (?, ?, "responsable")
            ');
            $query->execute([$id_projet, $id_enseignant]);
            
            $this->db->commit();
            return $id_projet;
        } catch (Exception $e) {
            $this->db->rollBack();
            return false;
        }
    }
    
    public function creerGroupe($id_projet, $titre) {
        $query = $this->db->prepare('
            INSERT INTO groupe_projet (id_projet, titre) 
            VALUES (?, ?)
        ');
        $query->execute([$id_projet, $titre]);
        return $this->db->lastInsertId();
    }
    
    public function ajouterEtudiantGroupe($id_groupe, $id_etudiant) {
        $query = $this->db->prepare('
            INSERT INTO groupe_etudiant (id_groupe, id_etudiant) 
            VALUES (?, ?)
        ');
        return $query->execute([$id_groupe, $id_etudiant]);
    }
    
    public function getEtudiants() {
        $query = $this->db->prepare('
            SELECT id, nom, prenom, login 
            FROM utilisateurs 
            WHERE role = "etudiant"
            ORDER BY nom, prenom
        ');
        $query->execute();
        return $query->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public function ajouterResponsable($id_projet, $id_enseignant, $role) {
        $query = $this->db->prepare('
            INSERT INTO projet_responsable (id_projet, id_enseignant, role) 
            VALUES (?, ?, ?)
        ');
        return $query->execute([$id_projet, $id_enseignant, $role]);
    }
}