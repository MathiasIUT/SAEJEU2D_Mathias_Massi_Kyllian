<?php
require_once 'modele_projet.php';
require_once 'vue_projet.php';

class Controleur_projet {
    private $modele;
    private $vue;
    
    public function __construct() {
        $this->modele = new Modele_projet();
        $this->vue = new Vue_projet();
    }
    
    public function creerProjet() {
        // Vérifier que l'utilisateur est un enseignant
        if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'enseignant') {
            $_SESSION['flash'] = [
                'type' => 'danger',
                'message' => 'Accès non autorisé'
            ];
            header('Location: index.php');
            exit;
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $titre = $_POST['titre'] ?? '';
            $description = $_POST['description'] ?? '';
            $annee = $_POST['annee'] ?? '';
            $semestre = $_POST['semestre'] ?? '';
            $travail_groupe = isset($_POST['travail_groupe']) ? 1 : 0;
            $groupe_modifiable = isset($_POST['groupe_modifiable']) ? 1 : 0;
            
            // Validation
            if (empty($titre) || empty($annee) || empty($semestre)) {
                $this->vue->afficherFormulaire([
                    'error' => 'Veuillez remplir tous les champs obligatoires'
                ]);
                return;
            }
            
            // Création du projet
            $id_projet = $this->modele->creerProjet(
                $titre, 
                $description, 
                $annee, 
                $semestre, 
                $travail_groupe,
                $groupe_modifiable,
                $_SESSION['user']['id']
            );
            
            if ($id_projet) {
                // Si le projet est en groupe et qu'on a sélectionné des étudiants
                if ($travail_groupe && isset($_POST['etudiants'])) {
                    $etudiants = $_POST['etudiants'];
                    $titre_groupe = $_POST['titre_groupe'] ?? "Groupe par défaut";
                    
                    // Créer le groupe et y ajouter les étudiants
                    $id_groupe = $this->modele->creerGroupe($id_projet, $titre_groupe);
                    if ($id_groupe) {
                        foreach ($etudiants as $id_etudiant) {
                            $this->modele->ajouterEtudiantGroupe($id_groupe, $id_etudiant);
                        }
                    }
                }
                
                $_SESSION['flash'] = [
                    'type' => 'success',
                    'message' => 'Projet créé avec succès'
                ];
                header('Location: index.php?module=projet&action=list');
                exit;
            }
            
            $this->vue->afficherFormulaire([
                'error' => 'Erreur lors de la création du projet'
            ]);
        } else {
            // Récupérer la liste des étudiants pour le formulaire
            $etudiants = $this->modele->getEtudiants();
            $this->vue->afficherFormulaire(['etudiants' => $etudiants]);
        }
    }
    
    public function ajouterResponsable() {
        if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'enseignant') {
            $_SESSION['flash'] = [
                'type' => 'danger',
                'message' => 'Accès non autorisé'
            ];
            header('Location: index.php');
            exit;
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $id_projet = $_POST['id_projet'] ?? 0;
            $id_enseignant = $_POST['id_enseignant'] ?? 0;
            $role = $_POST['role'] ?? 'intervenant'; // responsable ou intervenant
            
            if ($this->modele->ajouterResponsable($id_projet, $id_enseignant, $role)) {
                $_SESSION['flash'] = [
                    'type' => 'success',
                    'message' => 'Enseignant ajouté avec succès'
                ];
            } else {
                $_SESSION['flash'] = [
                    'type' => 'danger',
                    'message' => 'Erreur lors de l\'ajout de l\'enseignant'
                ];
            }
            header('Location: index.php?module=projet&action=details&id=' . $id_projet);
            exit;
        }
    }
}