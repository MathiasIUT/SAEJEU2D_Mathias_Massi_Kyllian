<?php
require_once 'controleur_evaluation.php';

class Module_evaluation {
    private $controleur;
    
    public function __construct() {
        $this->controleur = new Controleur_evaluation();
    }
    
    public function execute($action) {
        switch ($action) {
            case 'evaluer':
                $this->controleur->evaluerRendu();
                break;
            case 'deleguer':
                $this->controleur->deleguerEvaluation();
                break;
            case 'list':
                $this->controleur->listerEvaluations();
                break;
            default:
                $this->controleur->listerEvaluations();
        }
    }
}