<?php
require_once ROOT_PATH . '/core/Model.php';

class Modele_evaluation extends Model {
    public function evaluerRendu($id_rendu, $id_evaluateur, $note, $commentaire) {
        try {
            $this->db->beginTransaction();
            
            // Vérifier si une évaluation existe déjà
            $query = $this->db->prepare('
                SELECT id_evaluation FROM evaluation 
                WHERE id_rendu = ? AND id_evaluateur = ?
            ');
            $query->execute([$id_rendu, $id_evaluateur]);
            $evaluation = $query->fetch();
            
            if ($evaluation) {
                // Mettre à jour l'évaluation existante
                $query = $this->db->prepare('
                    UPDATE evaluation 
                    SET note = ?, commentaire = ?, date_evaluation = CURRENT_TIMESTAMP
                    WHERE id_evaluation = ?
                ');
                $success = $query->execute([$note, $commentaire, $evaluation['id_evaluation']]);
            } else {
                // Créer une nouvelle évaluation
                $query = $this->db->prepare('
                    INSERT INTO evaluation (id_rendu, id_evaluateur, note, commentaire, date_evaluation)
                    VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP)
                ');
                $success = $query->execute([$id_rendu, $id_evaluateur, $note, $commentaire]);
            }
            
            if ($success) {
                $this->db->commit();
                return true;
            }
            
            $this->db->rollBack();
            return false;
        } catch (PDOException $e) {
            $this->db->rollBack();
            error_log("Erreur lors de l'évaluation du rendu: " . $e->getMessage());
            return false;
        }
    }
    
    public function getRenduById($id_rendu) {
        $query = $this->db->prepare('
            SELECT r.*, p.titre as projet_titre, gp.titre as groupe_titre,
                   GROUP_CONCAT(DISTINCT CONCAT(u.prenom, " ", u.nom)) as etudiants
            FROM rendu_projet r
            JOIN projet p ON r.id_projet = p.id_projet
            JOIN groupe_projet gp ON r.id_groupe = gp.id_groupe
            JOIN groupe_etudiant ge ON gp.id_groupe = ge.id_groupe
            JOIN utilisateurs u ON ge.id_etudiant = u.id
            WHERE r.id_rendu = ?
            GROUP BY r.id_rendu
        ');
        $query->execute([$id_rendu]);
        return $query->fetch(PDO::FETCH_ASSOC);
    }
    
    public function getEvaluationsRendu($id_rendu) {
        $query = $this->db->prepare('
            SELECT e.*, u.login as evaluateur_login
            FROM evaluation e
            JOIN utilisateurs u ON e.id_evaluateur = u.id
            WHERE e.id_rendu = ?
            ORDER BY e.date_evaluation DESC
        ');
        $query->execute([$id_rendu]);
        return $query->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public function peutEvaluerRendu($id_rendu, $id_utilisateur) {
        $query = $this->db->prepare('
            SELECT COUNT(*) as count
            FROM rendu_projet r
            JOIN projet p ON r.id_projet = p.id_projet
            LEFT JOIN projet_responsable pr ON p.id_projet = pr.id_projet
            WHERE r.id_rendu = ?
            AND (
                p.id_responsable = ?
                OR pr.id_enseignant = ?
                OR ? IN (SELECT id FROM utilisateurs WHERE role = "admin")
            )
        ');
        $query->execute([$id_rendu, $id_utilisateur, $id_utilisateur, $id_utilisateur]);
        return $query->fetch()['count'] > 0;
    }
    
    public function peutDeleguerEvaluation($id_rendu, $id_utilisateur) {
        return $this->peutEvaluerRendu($id_rendu, $id_utilisateur);
    }
    
    public function deleguerEvaluation($id_rendu, $id_nouvel_evaluateur) {
        try {
            $query = $this->db->prepare('
                UPDATE evaluation 
                SET date_delegation = CURRENT_TIMESTAMP
                WHERE id_rendu = ? AND id_evaluateur = ?
            ');
            
            // Créer une nouvelle évaluation pour le nouvel évaluateur
            $query2 = $this->db->prepare('
                INSERT INTO evaluation (id_rendu, id_evaluateur, date_evaluation)
                VALUES (?, ?, CURRENT_TIMESTAMP)
            ');
            
            return $query->execute([$id_rendu, $id_nouvel_evaluateur]);
        } catch (PDOException $e) {
            error_log("Erreur lors de la délégation de l'évaluation: " . $e->getMessage());
            return false;
        }
    }
    
    public function getEvaluationsParEnseignant($id_enseignant) {
        $query = $this->db->prepare('
            SELECT e.*, r.id_projet, p.titre as projet_titre, 
                   gp.titre as groupe_titre, r.date_creation as date_rendu
            FROM evaluation e
            JOIN rendu_projet r ON e.id_rendu = r.id_rendu
            JOIN projet p ON r.id_projet = p.id_projet
            JOIN groupe_projet gp ON r.id_groupe = gp.id_groupe
            WHERE e.id_evaluateur = ?
            ORDER BY e.date_evaluation DESC
        ');
        $query->execute([$id_enseignant]);
        return $query->fetchAll(PDO::FETCH_ASSOC);
    }
}