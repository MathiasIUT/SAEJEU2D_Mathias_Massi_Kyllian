<?php
require_once ROOT_PATH . '/core/View.php';

class Vue_evaluation extends View {
    public function afficherEvaluation($data = []) {
        $this->render('evaluation/formulaire', $data);
    }
    
    public function afficherListe($data = []) {
        $this->render('evaluation/liste', $data);
    }
}