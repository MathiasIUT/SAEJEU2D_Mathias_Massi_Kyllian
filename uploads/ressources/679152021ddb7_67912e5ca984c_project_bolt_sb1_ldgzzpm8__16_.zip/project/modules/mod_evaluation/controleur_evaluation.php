<?php
require_once 'modele_evaluation.php';
require_once 'vue_evaluation.php';

class Controleur_evaluation {
    private $modele;
    private $vue;
    
    public function __construct() {
        $this->modele = new Modele_evaluation();
        $this->vue = new Vue_evaluation();
    }
    
    public function evaluerRendu() {
        // Vérifier que l'utilisateur est enseignant ou admin
        if (!in_array($_SESSION['user']['role'], ['enseignant', 'admin'])) {
            $_SESSION['flash'] = [
                'type' => 'danger',
                'message' => 'Vous n\'avez pas les droits pour évaluer les rendus'
            ];
            header('Location: index.php?module=rendu&action=list');
            exit;
        }

        $id_rendu = $_GET['id'] ?? 0;
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $note = $_POST['note'] ?? null;
            $commentaire = $_POST['commentaire'] ?? '';
            
            // Validation de la note
            if ($note !== null && ($note < 0 || $note > 20)) {
                $this->vue->afficherEvaluation([
                    'error' => 'La note doit être comprise entre 0 et 20',
                    'rendu' => $this->modele->getRenduById($id_rendu)
                ]);
                return;
            }
            
            if ($this->modele->evaluerRendu($id_rendu, $_SESSION['user']['id'], $note, $commentaire)) {
                $_SESSION['flash'] = [
                    'type' => 'success',
                    'message' => 'Évaluation enregistrée avec succès'
                ];
                header('Location: index.php?module=rendu&action=list');
                exit;
            } else {
                $this->vue->afficherEvaluation([
                    'error' => 'Erreur lors de l\'enregistrement de l\'évaluation',
                    'rendu' => $this->modele->getRenduById($id_rendu)
                ]);
            }
        } else {
            $rendu = $this->modele->getRenduById($id_rendu);
            if (!$rendu) {
                $_SESSION['flash'] = [
                    'type' => 'danger',
                    'message' => 'Rendu non trouvé'
                ];
                header('Location: index.php?module=rendu&action=list');
                exit;
            }
            
            // Vérifier que l'utilisateur peut évaluer ce rendu
            if (!$this->modele->peutEvaluerRendu($id_rendu, $_SESSION['user']['id'])) {
                $_SESSION['flash'] = [
                    'type' => 'danger',
                    'message' => 'Vous n\'avez pas les droits pour évaluer ce rendu'
                ];
                header('Location: index.php?module=rendu&action=list');
                exit;
            }
            
            $this->vue->afficherEvaluation([
                'rendu' => $rendu,
                'evaluations' => $this->modele->getEvaluationsRendu($id_rendu)
            ]);
        }
    }
    
    public function deleguerEvaluation() {
        if (!in_array($_SESSION['user']['role'], ['enseignant', 'admin'])) {
            $_SESSION['flash'] = [
                'type' => 'danger',
                'message' => 'Vous n\'avez pas les droits pour déléguer des évaluations'
            ];
            header('Location: index.php?module=rendu&action=list');
            exit;
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $id_rendu = $_POST['id_rendu'] ?? 0;
            $id_nouvel_evaluateur = $_POST['id_nouvel_evaluateur'] ?? 0;
            
            if (!$id_rendu || !$id_nouvel_evaluateur) {
                $_SESSION['flash'] = [
                    'type' => 'danger',
                    'message' => 'Paramètres manquants'
                ];
                header('Location: index.php?module=rendu&action=list');
                exit;
            }
            
            // Vérifier que l'utilisateur peut déléguer ce rendu
            if (!$this->modele->peutDeleguerEvaluation($id_rendu, $_SESSION['user']['id'])) {
                $_SESSION['flash'] = [
                    'type' => 'danger',
                    'message' => 'Vous n\'avez pas les droits pour déléguer cette évaluation'
                ];
                header('Location: index.php?module=rendu&action=list');
                exit;
            }
            
            if ($this->modele->deleguerEvaluation($id_rendu, $id_nouvel_evaluateur)) {
                $_SESSION['flash'] = [
                    'type' => 'success',
                    'message' => 'Évaluation déléguée avec succès'
                ];
            } else {
                $_SESSION['flash'] = [
                    'type' => 'danger',
                    'message' => 'Erreur lors de la délégation de l\'évaluation'
                ];
            }
            header('Location: index.php?module=rendu&action=list');
            exit;
        }
    }
    
    public function listerEvaluations() {
        if (!in_array($_SESSION['user']['role'], ['enseignant', 'admin'])) {
            $_SESSION['flash'] = [
                'type' => 'danger',
                'message' => 'Accès non autorisé'
            ];
            header('Location: index.php');
            exit;
        }

        $evaluations = $this->modele->getEvaluationsParEnseignant($_SESSION['user']['id']);
        $this->vue->afficherListe(['evaluations' => $evaluations]);
    }
}