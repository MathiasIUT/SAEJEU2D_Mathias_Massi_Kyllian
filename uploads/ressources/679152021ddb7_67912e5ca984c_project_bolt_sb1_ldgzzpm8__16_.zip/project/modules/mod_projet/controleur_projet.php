<?php
require_once 'modele_projet.php';
require_once 'vue_projet.php';

class Controleur_projet {
    private $modele;
    private $vue;
    private $db;
    
    public function __construct() {
        $this->modele = new Modele_projet();
        $this->vue = new Vue_projet();
        $this->db = Connexion::getConnexion();
    }
    
    public function creerProjet() {
        // Vérifier que l'utilisateur est un enseignant ou admin
        if (!isset($_SESSION['user']) || !in_array($_SESSION['user']['role'], ['enseignant', 'admin'])) {
            header('Location: index.php?module=projet&action=list');
            return;
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $titre = $_POST['titre'] ?? '';
            $description = $_POST['description'] ?? '';
            $semestre = $_POST['semestre'] ?? '';
            $trello_link = $_POST['trello_link'] ?? '';
            $git_link = $_POST['git_link'] ?? '';
            $id_responsable = $_SESSION['user']['id'];
            $co_responsables = $_POST['co_responsables'] ?? [];
            $intervenants = $_POST['intervenants'] ?? [];
            
            try {
                // Vérifier que l'utilisateur existe bien
                if (!$this->modele->utilisateurExiste($id_responsable)) {
                    $this->vue->afficherFormulaire([
                        'error' => 'Erreur : utilisateur non trouvé',
                        'enseignants' => $this->modele->getEnseignantsDisponibles()
                    ]);
                    return;
                }
                
                if ($this->modele->creerProjet($titre, $description, $semestre, $trello_link, $git_link, $id_responsable, $co_responsables, $intervenants)) {
                    $_SESSION['flash'] = ['type' => 'success', 'message' => 'Projet créé avec succès'];
                    header('Location: index.php?module=projet&action=list');
                    return;
                }
            } catch (Exception $e) {
                $this->vue->afficherFormulaire([
                    'error' => 'Erreur lors de la création du projet: ' . $e->getMessage(),
                    'enseignants' => $this->modele->getEnseignantsDisponibles()
                ]);
                return;
            }
        }
        
        // Récupérer la liste des enseignants pour le formulaire
        $enseignants = $this->modele->getEnseignantsDisponibles();
        $this->vue->afficherFormulaire(['enseignants' => $enseignants]);
    }
    
    public function listerProjets() {
        $projets = $this->modele->getProjets();
        $this->vue->afficherListe($projets);
    }
    
    public function modifierProjet() {
        $id = $_GET['id'] ?? 0;
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            try {
                $this->db->beginTransaction();
                
                $titre = $_POST['titre'] ?? '';
                $description = $_POST['description'] ?? '';
                $semestre = $_POST['semestre'] ?? '';
                $trello_link = $_POST['trello_link'] ?? '';
                $git_link = $_POST['git_link'] ?? '';
                $co_responsables = $_POST['co_responsables'] ?? [];
                $intervenants = $_POST['intervenants'] ?? [];
                
                if ($this->modele->modifierProjet($id, $titre, $description, $semestre, $trello_link, $git_link)) {
                    // Mise à jour des co-responsables
                    $this->modele->supprimerCollaborateurs($id);
                    foreach ($co_responsables as $id_enseignant) {
                        $this->modele->ajouterCollaborateur($id, $id_enseignant, 'co-responsable');
                    }
                    foreach ($intervenants as $id_enseignant) {
                        $this->modele->ajouterCollaborateur($id, $id_enseignant, 'intervenant');
                    }
                    
                    $this->db->commit();
                    $_SESSION['flash'] = ['type' => 'success', 'message' => 'Projet modifié avec succès'];
                    header('Location: index.php?module=projet&action=list');
                    return;
                }
            } catch (Exception $e) {
                $this->db->rollBack();
                $projet = $this->modele->getProjetById($id);
                $enseignants = $this->modele->getEnseignantsDisponibles();
                $this->vue->afficherFormulaire([
                    'error' => 'Erreur lors de la modification: ' . $e->getMessage(),
                    'projet' => $projet,
                    'enseignants' => $enseignants
                ]);
                return;
            }
        }
        
        $projet = $this->modele->getProjetById($id);
        $enseignants = $this->modele->getEnseignantsDisponibles();
        $this->vue->afficherFormulaire([
            'projet' => $projet,
            'enseignants' => $enseignants
        ]);
    }
    
    public function supprimerProjet() {
        $id = $_GET['id'] ?? 0;
        if ($this->modele->supprimerProjet($id)) {
            $_SESSION['flash'] = ['type' => 'success', 'message' => 'Projet supprimé avec succès'];
        }
        header('Location: index.php?module=projet&action=list');
    }

    public function gererSoutenances() {
        $id_projet = $_GET['id'] ?? 0;
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $action = $_POST['action'] ?? '';
            
            switch ($action) {
                case 'creer_soutenance':
                    $date = $_POST['date'] ?? '';
                    $duree = $_POST['duree'] ?? '';
                    $salle = $_POST['salle'] ?? '';
                    
                    if ($this->modele->creerSoutenance($id_projet, $date, $duree, $salle)) {
                        $_SESSION['flash'] = ['type' => 'success', 'message' => 'Soutenance créée avec succès'];
                    }
                    break;
                    
                case 'planifier_passage':
                    $id_soutenance = $_POST['id_soutenance'] ?? 0;
                    $id_groupe = $_POST['id_groupe'] ?? 0;
                    $heure_passage = $_POST['heure_passage'] ?? '';
                    
                    if ($this->modele->planifierPassage($id_soutenance, $id_groupe, $heure_passage)) {
                        $_SESSION['flash'] = ['type' => 'success', 'message' => 'Passage planifié avec succès'];
                    }
                    break;
            }
        }
        
        $soutenances = $this->modele->getSoutenancesProjet($id_projet);
        $groupes = $this->modele->getGroupesProjet($id_projet);
        
        $this->vue->afficherSoutenances([
            'soutenances' => $soutenances,
            'groupes' => $groupes,
            'id_projet' => $id_projet
        ]);
    }
}