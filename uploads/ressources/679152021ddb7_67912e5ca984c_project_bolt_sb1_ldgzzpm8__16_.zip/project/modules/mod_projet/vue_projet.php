<?php
require_once ROOT_PATH . '/core/View.php';

class Vue_projet extends View {
    public function afficherFormulaire($data = []) {
        $this->render('projet/formulaire', $data);
    }
    
    public function afficherListe($projets) {
        $this->render('projet/liste', ['projets' => $projets]);
    }
    
    public function afficherGroupes($data) {
        $this->render('projet/groupes', $data);
    }
    
    public function afficherChamps($data) {
        $this->render('projet/champs', $data);
    }
    
    public function afficherRendus($data) {
        $this->render('projet/rendus', $data);
    }
    
    public function afficherRessources($data) {
        $this->render('projet/ressources', $data);
    }
    
    public function afficherSoutenances($data) {
        $this->render('projet/soutenances', $data);
    }
    
    public function afficherCompetences($data) {
        $this->render('projet/competences', $data);
    }
    
    public function afficherNotifications($data) {
        $this->render('projet/notifications', $data);
    }
    
    public function afficherStatistiques($data) {
        $this->render('projet/statistiques', $data);
    }
}