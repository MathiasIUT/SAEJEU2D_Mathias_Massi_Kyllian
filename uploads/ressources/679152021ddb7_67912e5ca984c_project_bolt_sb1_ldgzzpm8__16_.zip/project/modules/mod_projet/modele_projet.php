<?php
require_once ROOT_PATH . '/core/Model.php';

class Modele_projet extends Model {
    public function utilisateurExiste($id_utilisateur) {
        try {
            // Debug: Afficher la requête SQL
            error_log("Vérification de l'existence de l'utilisateur ID: " . $id_utilisateur);
            
            $query = $this->db->prepare('SELECT COUNT(*) as count FROM utilisateurs WHERE id = ?');
            $query->execute([$id_utilisateur]);
            $result = $query->fetch(PDO::FETCH_ASSOC);
            
            error_log("Résultat de la vérification: " . print_r($result, true));
            
            return $result['count'] > 0;
        } catch (Exception $e) {
            error_log("Erreur lors de la vérification de l'utilisateur: " . $e->getMessage());
            throw $e;
        }
    }

    public function creerProjet($titre, $description, $semestre, $trello_link, $git_link, $id_responsable, $co_responsables = [], $intervenants = []) {
        try {
            $this->db->beginTransaction();
            
            // Debug: Afficher les paramètres
            error_log("Création projet - Paramètres: " . print_r([
                'titre' => $titre,
                'description' => $description,
                'semestre' => $semestre,
                'id_responsable' => $id_responsable
            ], true));
            
            // Vérifier que l'utilisateur existe
            if (!$this->utilisateurExiste($id_responsable)) {
                throw new Exception("L'utilisateur responsable n'existe pas");
            }
            
            // Création du projet
            $query = $this->db->prepare('
                INSERT INTO projet (titre, description, semestre, date_debut, date_fin, trello_link, git_link, id_responsable) 
                VALUES (?, ?, ?, CURRENT_DATE, DATE_ADD(CURRENT_DATE, INTERVAL 3 MONTH), ?, ?, ?)
            ');
            $success = $query->execute([$titre, $description, $semestre, $trello_link, $git_link, $id_responsable]);
            
            if (!$success) {
                error_log("Erreur lors de l'insertion du projet: " . print_r($query->errorInfo(), true));
                throw new Exception("Erreur lors de la création du projet");
            }
            
            $id_projet = $this->db->lastInsertId();
            
            // Ajout du responsable principal
            $query = $this->db->prepare('
                INSERT INTO projet_responsable (id_projet, id_enseignant, role) 
                VALUES (?, ?, ?)
            ');
            $success = $query->execute([$id_projet, $id_responsable, 'responsable']);
            
            if (!$success) {
                error_log("Erreur lors de l'ajout du responsable: " . print_r($query->errorInfo(), true));
                throw new Exception("Erreur lors de l'ajout du responsable");
            }
            
            // Ajout des co-responsables
            foreach ($co_responsables as $id_enseignant) {
                if ($id_enseignant != $id_responsable) {
                    $query = $this->db->prepare('
                        INSERT INTO projet_responsable (id_projet, id_enseignant, role) 
                        VALUES (?, ?, ?)
                    ');
                    $query->execute([$id_projet, $id_enseignant, 'co-responsable']);
                }
            }
            
            // Ajout des intervenants
            foreach ($intervenants as $id_enseignant) {
                if ($id_enseignant != $id_responsable && !in_array($id_enseignant, $co_responsables)) {
                    $query = $this->db->prepare('
                        INSERT INTO projet_responsable (id_projet, id_enseignant, role) 
                        VALUES (?, ?, ?)
                    ');
                    $query->execute([$id_projet, $id_enseignant, 'intervenant']);
                }
            }
            
            $this->db->commit();
            return true;
        } catch (Exception $e) {
            $this->db->rollBack();
            error_log("Erreur lors de la création du projet: " . $e->getMessage());
            throw $e;
        }
    }
    
    public function getProjets() {
        $query = $this->db->prepare('
            SELECT p.*, u.login as responsable,
                   GROUP_CONCAT(DISTINCT 
                       CASE pr.role 
                           WHEN "co-responsable" THEN u2.login 
                       END) as co_responsables,
                   GROUP_CONCAT(DISTINCT 
                       CASE pr.role 
                           WHEN "intervenant" THEN u2.login 
                       END) as intervenants
            FROM projet p 
            JOIN utilisateurs u ON p.id_responsable = u.id
            LEFT JOIN projet_responsable pr ON p.id_projet = pr.id_projet
            LEFT JOIN utilisateurs u2 ON pr.id_enseignant = u2.id
            GROUP BY p.id_projet
            ORDER BY p.date_creation DESC
        ');
        $query->execute();
        return $query->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public function getProjetById($id) {
        $query = $this->db->prepare('
            SELECT p.*, 
                   GROUP_CONCAT(DISTINCT 
                       CASE pr.role 
                           WHEN "co-responsable" THEN pr.id_enseignant 
                       END) as co_responsables,
                   GROUP_CONCAT(DISTINCT 
                       CASE pr.role 
                           WHEN "intervenant" THEN pr.id_enseignant 
                       END) as intervenants
            FROM projet p
            LEFT JOIN projet_responsable pr ON p.id_projet = pr.id_projet
            WHERE p.id_projet = ?
            GROUP BY p.id_projet
        ');
        $query->execute([$id]);
        return $query->fetch(PDO::FETCH_ASSOC);
    }
    
    public function modifierProjet($id, $titre, $description, $semestre, $trello_link, $git_link) {
        $query = $this->db->prepare('
            UPDATE projet 
            SET titre = ?, description = ?, semestre = ?, trello_link = ?, git_link = ? 
            WHERE id_projet = ?
        ');
        return $query->execute([$titre, $description, $semestre, $trello_link, $git_link, $id]);
    }
    
    public function supprimerProjet($id) {
        $query = $this->db->prepare('DELETE FROM projet WHERE id_projet = ?');
        return $query->execute([$id]);
    }
    
    public function getEnseignantsDisponibles() {
        $query = $this->db->prepare('
            SELECT id, login, nom, prenom 
            FROM utilisateurs 
            WHERE role = "enseignant" 
            ORDER BY nom, prenom
        ');
        $query->execute();
        return $query->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public function ajouterCollaborateur($id_projet, $id_enseignant, $role) {
        $query = $this->db->prepare('
            INSERT INTO projet_responsable (id_projet, id_enseignant, role) 
            VALUES (?, ?, ?)
            ON DUPLICATE KEY UPDATE role = ?
        ');
        return $query->execute([$id_projet, $id_enseignant, $role, $role]);
    }
    
    public function supprimerCollaborateurs($id_projet) {
        $query = $this->db->prepare('
            DELETE FROM projet_responsable 
            WHERE id_projet = ? AND role != "responsable"
        ');
        return $query->execute([$id_projet]);
    }

    public function getGroupesProjet($id_projet) {
        $query = $this->db->prepare('
            SELECT gp.*, 
                   COUNT(ge.id_etudiant) as nb_etudiants,
                   GROUP_CONCAT(CONCAT(u.prenom, " ", u.nom)) as membres
            FROM groupe_projet gp
            LEFT JOIN groupe_etudiant ge ON gp.id_groupe = ge.id_groupe
            LEFT JOIN utilisateurs u ON ge.id_etudiant = u.id
            WHERE gp.id_projet = ?
            GROUP BY gp.id_groupe
        ');
        $query->execute([$id_projet]);
        return $query->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getEtudiantsProjet($id_projet) {
        $query = $this->db->prepare('
            SELECT u.* 
            FROM utilisateurs u
            JOIN groupe_etudiant ge ON u.id = ge.id_etudiant
            JOIN groupe_projet gp ON ge.id_groupe = gp.id_groupe
            WHERE gp.id_projet = ?
        ');
        $query->execute([$id_projet]);
        return $query->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getSoutenancesProjet($id_projet) {
        $query = $this->db->prepare('
            SELECT s.*, 
                   COUNT(sg.id_groupe) as nb_passages,
                   GROUP_CONCAT(
                       CONCAT(g.titre, " - ", sg.heure_passage)
                       ORDER BY sg.heure_passage
                       SEPARATOR "|"
                   ) as passages
            FROM soutenance s
            LEFT JOIN soutenance_groupe sg ON s.id_soutenance = sg.id_soutenance
            LEFT JOIN groupe_projet g ON sg.id_groupe = g.id_groupe
            WHERE s.id_projet = ?
            GROUP BY s.id_soutenance
            ORDER BY s.date_soutenance, s.id_soutenance
        ');
        $query->execute([$id_projet]);
        $soutenances = $query->fetchAll(PDO::FETCH_ASSOC);
        
        // Formater les passages
        foreach ($soutenances as &$soutenance) {
            if ($soutenance['passages']) {
                $passages = [];
                foreach (explode('|', $soutenance['passages']) as $passage) {
                    list($groupe, $heure) = explode(' - ', $passage);
                    $passages[] = [
                        'groupe_titre' => $groupe,
                        'heure_passage' => $heure
                    ];
                }
                $soutenance['passages'] = $passages;
            } else {
                $soutenance['passages'] = [];
            }
        }
        
        return $soutenances;
    }

    public function creerSoutenance($id_projet, $date, $duree, $salle) {
        $query = $this->db->prepare('
            INSERT INTO soutenance (id_projet, date_soutenance, duree, salle)
            VALUES (?, ?, ?, ?)
        ');
        return $query->execute([$id_projet, $date, $duree, $salle]);
    }

    public function planifierPassage($id_soutenance, $id_groupe, $heure_passage) {
        $query = $this->db->prepare('
            INSERT INTO soutenance_groupe (id_soutenance, id_groupe, heure_passage)
            VALUES (?, ?, ?)
        ');
        return $query->execute([$id_soutenance, $id_groupe, $heure_passage]);
    }

    public function supprimerSoutenance($id_soutenance) {
        $query = $this->db->prepare('DELETE FROM soutenance WHERE id_soutenance = ?');
        return $query->execute([$id_soutenance]);
    }
}