<?php
require_once 'controleur_projet.php';

class Module_projet {
    private $controleur;
    
    public function __construct() {
        $this->controleur = new Controleur_projet();
    }
    
    public function execute($action) {
        switch ($action) {
            case 'create':
                $this->controleur->creerProjet();
                break;
            case 'list':
                $this->controleur->listerProjets();
                break;
            case 'edit':
                $this->controleur->modifierProjet();
                break;
            case 'delete':
                $this->controleur->supprimerProjet();
                break;
            case 'competences':
                $this->controleur->gererCompetences();
                break;
            case 'soutenances':
                $this->controleur->gererSoutenances();
                break;
            default:
                $this->controleur->listerProjets();
        }
    }
}