<?php
require_once ROOT_PATH . '/core/Model.php';

class Modele_ressource extends Model {
    public function creerRessource($id_projet, $titre, $type, $url, $description, $id_createur) {
        try {
            $query = $this->db->prepare('
                INSERT INTO ressource (id_projet, titre, type, url, description, id_createur)
                VALUES (?, ?, ?, ?, ?, ?)
            ');
            return $query->execute([$id_projet, $titre, $type, $url, $description, $id_createur]);
        } catch (PDOException $e) {
            error_log("Erreur lors de la création de la ressource: " . $e->getMessage());
            return false;
        }
    }
    
    public function getRessourceById($id_ressource) {
        $query = $this->db->prepare('
            SELECT r.*, u.login as createur_login
            FROM ressource r
            JOIN utilisateurs u ON r.id_createur = u.id
            WHERE r.id_ressource = ?
        ');
        $query->execute([$id_ressource]);
        return $query->fetch(PDO::FETCH_ASSOC);
    }
    
    public function getRessourcesByProjet($id_projet) {
        $query = $this->db->prepare('
            SELECT r.*, u.login as createur_login
            FROM ressource r
            JOIN utilisateurs u ON r.id_createur = u.id
            WHERE r.id_projet = ?
            ORDER BY r.est_mise_en_avant DESC, r.date_creation DESC
        ');
        $query->execute([$id_projet]);
        return $query->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public function toggleMiseEnAvant($id_ressource, $nouvelle_valeur) {
        try {
            $query = $this->db->prepare('
                UPDATE ressource 
                SET est_mise_en_avant = ?
                WHERE id_ressource = ?
            ');
            return $query->execute([$nouvelle_valeur ? 1 : 0, $id_ressource]);
        } catch (PDOException $e) {
            error_log("Erreur lors de la modification de la mise en avant: " . $e->getMessage());
            return false;
        }
    }
    
    public function supprimerRessource($id_ressource) {
        try {
            $query = $this->db->prepare('DELETE FROM ressource WHERE id_ressource = ?');
            return $query->execute([$id_ressource]);
        } catch (PDOException $e) {
            error_log("Erreur lors de la suppression de la ressource: " . $e->getMessage());
            return false;
        }
    }
    
    public function getProjetsPourIntervenant($id_utilisateur) {
        $query = $this->db->prepare('
            SELECT DISTINCT p.*
            FROM projet p
            LEFT JOIN projet_responsable pr ON p.id_projet = pr.id_projet
            WHERE p.id_responsable = ?
               OR pr.id_enseignant = ?
               OR ? IN (SELECT id FROM utilisateurs WHERE role = "admin")
            ORDER BY p.date_creation DESC
        ');
        $query->execute([$id_utilisateur, $id_utilisateur, $id_utilisateur]);
        return $query->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public function peutVoirRessources($id_projet, $id_utilisateur) {
        $query = $this->db->prepare('
            SELECT COUNT(*) as count
            FROM projet p
            LEFT JOIN projet_responsable pr ON p.id_projet = pr.id_projet
            LEFT JOIN groupe_projet gp ON p.id_projet = gp.id_projet
            LEFT JOIN groupe_etudiant ge ON gp.id_groupe = ge.id_groupe
            WHERE p.id_projet = ?
            AND (
                p.id_responsable = ?
                OR pr.id_enseignant = ?
                OR ge.id_etudiant = ?
                OR ? IN (SELECT id FROM utilisateurs WHERE role = "admin")
            )
        ');
        $query->execute([$id_projet, $id_utilisateur, $id_utilisateur, $id_utilisateur, $id_utilisateur]);
        return $query->fetch()['count'] > 0;
    }
    
    public function estResponsableProjet($id_projet, $id_utilisateur) {
        $query = $this->db->prepare('
            SELECT COUNT(*) as count
            FROM projet p
            LEFT JOIN projet_responsable pr ON p.id_projet = pr.id_projet
            WHERE p.id_projet = ?
            AND (
                p.id_responsable = ?
                OR (pr.id_enseignant = ? AND pr.role IN ("responsable", "co-responsable"))
                OR ? IN (SELECT id FROM utilisateurs WHERE role = "admin")
            )
        ');
        $query->execute([$id_projet, $id_utilisateur, $id_utilisateur, $id_utilisateur]);
        return $query->fetch()['count'] > 0;
    }
}