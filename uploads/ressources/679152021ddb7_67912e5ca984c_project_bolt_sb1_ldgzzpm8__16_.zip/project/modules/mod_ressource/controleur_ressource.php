<?php
require_once 'modele_ressource.php';
require_once 'vue_ressource.php';

class Controleur_ressource {
    private $modele;
    private $vue;
    
    public function __construct() {
        $this->modele = new Modele_ressource();
        $this->vue = new Vue_ressource();
    }
    
    public function creerRessource() {
        // Vérifier que l'utilisateur est intervenant ou responsable
        if (!in_array($_SESSION['user']['role'], ['enseignant', 'admin'])) {
            $_SESSION['flash'] = [
                'type' => 'danger',
                'message' => 'Vous n\'avez pas les droits pour créer des ressources'
            ];
            header('Location: index.php?module=projet&action=list');
            exit;
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $id_projet = $_POST['id_projet'] ?? 0;
            $titre = $_POST['titre'] ?? '';
            $type = $_POST['type'] ?? '';
            $url = $_POST['url'] ?? '';
            $description = $_POST['description'] ?? '';
            
            // Validation des données
            if (empty($titre) || empty($url) || empty($type)) {
                $this->vue->afficherFormulaire([
                    'error' => 'Tous les champs obligatoires doivent être remplis',
                    'projets' => $this->modele->getProjetsPourIntervenant($_SESSION['user']['id'])
                ]);
                return;
            }

            // Validation de l'URL
            if (!filter_var($url, FILTER_VALIDATE_URL)) {
                $this->vue->afficherFormulaire([
                    'error' => 'L\'URL fournie n\'est pas valide',
                    'projets' => $this->modele->getProjetsPourIntervenant($_SESSION['user']['id'])
                ]);
                return;
            }

            if ($this->modele->creerRessource($id_projet, $titre, $type, $url, $description, $_SESSION['user']['id'])) {
                $_SESSION['flash'] = [
                    'type' => 'success',
                    'message' => 'Ressource créée avec succès'
                ];
                header('Location: index.php?module=ressource&action=list&id_projet=' . $id_projet);
                exit;
            } else {
                $this->vue->afficherFormulaire([
                    'error' => 'Erreur lors de la création de la ressource',
                    'projets' => $this->modele->getProjetsPourIntervenant($_SESSION['user']['id'])
                ]);
            }
        } else {
            $this->vue->afficherFormulaire([
                'projets' => $this->modele->getProjetsPourIntervenant($_SESSION['user']['id'])
            ]);
        }
    }
    
    public function listerRessources() {
        $id_projet = $_GET['id_projet'] ?? 0;
        
        if (!$id_projet) {
            $_SESSION['flash'] = [
                'type' => 'danger',
                'message' => 'ID du projet manquant'
            ];
            header('Location: index.php?module=projet&action=list');
            exit;
        }
        
        // Vérifier l'accès aux ressources
        if (!$this->modele->peutVoirRessources($id_projet, $_SESSION['user']['id'])) {
            $_SESSION['flash'] = [
                'type' => 'danger',
                'message' => 'Vous n\'avez pas accès aux ressources de ce projet'
            ];
            header('Location: index.php?module=projet&action=list');
            exit;
        }

        $ressources = $this->modele->getRessourcesByProjet($id_projet);
        $this->vue->afficherListe([
            'ressources' => $ressources,
            'id_projet' => $id_projet,
            'est_responsable' => $this->modele->estResponsableProjet($id_projet, $_SESSION['user']['id'])
        ]);
    }
    
    public function toggleMiseEnAvant() {
        $id_ressource = $_POST['id_ressource'] ?? 0;
        $ressource = $this->modele->getRessourceById($id_ressource);
        
        if (!$ressource) {
            $_SESSION['flash'] = [
                'type' => 'danger',
                'message' => 'Ressource non trouvée'
            ];
            header('Location: index.php?module=projet&action=list');
            exit;
        }
        
        // Vérifier que l'utilisateur est responsable du projet
        if (!$this->modele->estResponsableProjet($ressource['id_projet'], $_SESSION['user']['id'])) {
            $_SESSION['flash'] = [
                'type' => 'danger',
                'message' => 'Vous n\'avez pas les droits pour mettre en avant cette ressource'
            ];
            header('Location: index.php?module=ressource&action=list&id_projet=' . $ressource['id_projet']);
            exit;
        }

        $nouvelle_valeur = !$ressource['est_mise_en_avant'];
        if ($this->modele->toggleMiseEnAvant($id_ressource, $nouvelle_valeur)) {
            $_SESSION['flash'] = [
                'type' => 'success',
                'message' => 'Statut de mise en avant modifié avec succès'
            ];
        } else {
            $_SESSION['flash'] = [
                'type' => 'danger',
                'message' => 'Erreur lors de la modification du statut'
            ];
        }
        
        header('Location: index.php?module=ressource&action=list&id_projet=' . $ressource['id_projet']);
        exit;
    }
    
    public function supprimerRessource() {
        $id_ressource = $_GET['id'] ?? 0;
        $ressource = $this->modele->getRessourceById($id_ressource);
        
        if (!$ressource) {
            $_SESSION['flash'] = [
                'type' => 'danger',
                'message' => 'Ressource non trouvée'
            ];
            header('Location: index.php?module=projet&action=list');
            exit;
        }
        
        // Vérifier que l'utilisateur est le créateur ou responsable
        if ($ressource['id_createur'] !== $_SESSION['user']['id'] && 
            !$this->modele->estResponsableProjet($ressource['id_projet'], $_SESSION['user']['id'])) {
            $_SESSION['flash'] = [
                'type' => 'danger',
                'message' => 'Vous n\'avez pas les droits pour supprimer cette ressource'
            ];
            header('Location: index.php?module=ressource&action=list&id_projet=' . $ressource['id_projet']);
            exit;
        }

        if ($this->modele->supprimerRessource($id_ressource)) {
            $_SESSION['flash'] = [
                'type' => 'success',
                'message' => 'Ressource supprimée avec succès'
            ];
        } else {
            $_SESSION['flash'] = [
                'type' => 'danger',
                'message' => 'Erreur lors de la suppression de la ressource'
            ];
        }
        
        header('Location: index.php?module=ressource&action=list&id_projet=' . $ressource['id_projet']);
        exit;
    }
}