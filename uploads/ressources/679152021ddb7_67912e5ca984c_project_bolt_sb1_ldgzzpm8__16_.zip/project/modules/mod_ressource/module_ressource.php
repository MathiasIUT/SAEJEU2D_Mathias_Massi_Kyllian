<?php
require_once 'controleur_ressource.php';

class Module_ressource {
    private $controleur;
    
    public function __construct() {
        $this->controleur = new Controleur_ressource();
    }
    
    public function execute($action) {
        switch ($action) {
            case 'create':
                $this->controleur->creerRessource();
                break;
            case 'edit':
                $this->controleur->modifierRessource();
                break;
            case 'delete':
                $this->controleur->supprimerRessource();
                break;
            case 'toggle_highlight':
                $this->controleur->toggleMiseEnAvant();
                break;
            case 'list':
                $this->controleur->listerRessources();
                break;
            default:
                $this->controleur->listerRessources();
        }
    }
}