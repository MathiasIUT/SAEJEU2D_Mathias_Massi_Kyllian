<?php
require_once ROOT_PATH . '/core/Model.php';

class Modele_dashboard extends Model {
    // Méthodes pour l'admin
    public function getTotalUtilisateurs() {
        $query = $this->db->query('SELECT COUNT(*) as total FROM utilisateurs');
        return $query->fetch(PDO::FETCH_ASSOC)['total'];
    }
    
    public function getTotalProjets() {
        $query = $this->db->query('SELECT COUNT(*) as total FROM projet');
        return $query->fetch(PDO::FETCH_ASSOC)['total'];
    }
    
    public function getTotalRendus() {
        $query = $this->db->query('SELECT COUNT(*) as total FROM rendu_projet');
        return $query->fetch(PDO::FETCH_ASSOC)['total'];
    }
    
    public function getDerniersUtilisateurs() {
        $query = $this->db->query('SELECT * FROM utilisateurs ORDER BY id DESC LIMIT 5');
        return $query->fetchAll(PDO::FETCH_ASSOC);
    }
    
    // Méthodes pour l'enseignant
    public function getProjetsByEnseignant($id_enseignant) {
        $query = $this->db->prepare('SELECT * FROM projet WHERE id_responsable = ? ORDER BY id_projet DESC');
        $query->execute([$id_enseignant]);
        return $query->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public function getDerniersRendusByEnseignant($id_enseignant) {
        $query = $this->db->prepare('
            SELECT r.*, p.titre as projet_titre, u.login as etudiant_login 
            FROM rendu_projet r 
            JOIN projet p ON r.id_projet = p.id_projet 
            JOIN groupe_projet gp ON p.id_projet = gp.id_projet
            JOIN groupe_etudiant ge ON gp.id_groupe = ge.id_groupe
            JOIN utilisateurs u ON ge.id_etudiant = u.id
            WHERE p.id_responsable = ? 
            ORDER BY r.date_creation DESC 
            LIMIT 5
        ');
        $query->execute([$id_enseignant]);
        return $query->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public function getTotalEtudiants() {
        $query = $this->db->query("SELECT COUNT(*) as total FROM utilisateurs WHERE role = 'etudiant'");
        return $query->fetch(PDO::FETCH_ASSOC)['total'];
    }
    
    // Méthodes pour l'étudiant
    public function getProjetsByEtudiant($id_etudiant) {
        $query = $this->db->prepare('
            SELECT DISTINCT p.* 
            FROM projet p 
            JOIN groupe_projet gp ON p.id_projet = gp.id_projet
            JOIN groupe_etudiant ge ON gp.id_groupe = ge.id_groupe
            WHERE ge.id_etudiant = ? 
            ORDER BY p.id_projet DESC
        ');
        $query->execute([$id_etudiant]);
        return $query->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public function getRendusByEtudiant($id_etudiant) {
        $query = $this->db->prepare('
            SELECT r.*, p.titre as projet_titre 
            FROM rendu_projet r 
            JOIN projet p ON r.id_projet = p.id_projet 
            JOIN groupe_projet gp ON p.id_projet = gp.id_projet
            JOIN groupe_etudiant ge ON gp.id_groupe = ge.id_groupe
            WHERE ge.id_etudiant = ? 
            ORDER BY r.date_creation DESC
        ');
        $query->execute([$id_etudiant]);
        return $query->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public function getProchainRendus($id_etudiant) {
        // Cette méthode pourrait être étendue avec une table de dates limites
        return [];
    }
}