<?php
require_once 'modele_dashboard.php';
require_once 'vue_dashboard.php';

class Controleur_dashboard {
    private $modele;
    private $vue;
    
    public function __construct() {
        $this->modele = new Modele_dashboard();
        $this->vue = new Vue_dashboard();
    }
    
    public function afficherDashboard() {
        $data = [];
        
        switch ($_SESSION['user']['role']) {
            case 'admin':
                $data['total_utilisateurs'] = $this->modele->getTotalUtilisateurs();
                $data['total_projets'] = $this->modele->getTotalProjets();
                $data['total_rendus'] = $this->modele->getTotalRendus();
                $data['derniers_utilisateurs'] = $this->modele->getDerniersUtilisateurs();
                break;
                
            case 'enseignant':
                $id_enseignant = $_SESSION['user']['id'];
                $data['mes_projets'] = $this->modele->getProjetsByEnseignant($id_enseignant);
                $data['derniers_rendus'] = $this->modele->getDerniersRendusByEnseignant($id_enseignant);
                $data['total_etudiants'] = $this->modele->getTotalEtudiants();
                break;
                
            case 'etudiant':
                $id_etudiant = $_SESSION['user']['id'];
                $data['mes_projets'] = $this->modele->getProjetsByEtudiant($id_etudiant);
                $data['mes_rendus'] = $this->modele->getRendusByEtudiant($id_etudiant);
                $data['prochains_rendus'] = $this->modele->getProchainRendus($id_etudiant);
                break;
        }
        
        $this->vue->afficherDashboard($data);
    }
}