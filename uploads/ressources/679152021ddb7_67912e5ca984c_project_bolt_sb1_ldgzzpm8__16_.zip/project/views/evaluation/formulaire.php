<div class="container mt-4">
    <div class="card">
        <div class="card-header">
            <h2>Évaluation du rendu</h2>
        </div>
        <div class="card-body">
            <?php if (isset($error)): ?>
                <div class="alert alert-danger"><?php echo $error; ?></div>
            <?php endif; ?>

            <div class="row mb-4">
                <div class="col-md-6">
                    <h4>Informations du rendu</h4>
                    <dl class="row">
                        <dt class="col-sm-4">Projet</dt>
                        <dd class="col-sm-8"><?php echo htmlspecialchars($rendu['projet_titre']); ?></dd>
                        
                        <dt class="col-sm-4">Groupe</dt>
                        <dd class="col-sm-8"><?php echo htmlspecialchars($rendu['groupe_titre']); ?></dd>
                        
                        <dt class="col-sm-4">Étudiants</dt>
                        <dd class="col-sm-8"><?php echo htmlspecialchars($rendu['etudiants']); ?></dd>
                        
                        <dt class="col-sm-4">Date de rendu</dt>
                        <dd class="col-sm-8"><?php echo date('d/m/Y H:i', strtotime($rendu['date_creation'])); ?></dd>
                    </dl>

                    <?php if (!empty($rendu['commentaire_etudiant'])): ?>
                        <div class="alert alert-info">
                            <h5>Commentaire de l'étudiant :</h5>
                            <p class="mb-0"><?php echo nl2br(htmlspecialchars($rendu['commentaire_etudiant'])); ?></p>
                        </div>
                    <?php endif; ?>
                </div>

                <div class="col-md-6">
                    <h4>Fichiers rendus</h4>
                    <ul class="list-group">
                        <?php foreach (json_decode($rendu['fichiers']) as $fichier): ?>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                <?php echo htmlspecialchars($fichier); ?>
                                <a href="index.php?module=rendu&action=download&id=<?php echo $rendu['id_rendu']; ?>&fichier=<?php echo urlencode($fichier); ?>" 
                                   class="btn btn-sm btn-primary">
                                    Télécharger
                                </a>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            </div>

            <form method="POST">
                <div class="mb-3">
                    <label for="note" class="form-label">Note sur 20</label>
                    <input type="number" class="form-control" id="note" name="note" 
                           min="0" max="20" step="0.5" 
                           value="<?php echo isset($rendu['note']) ? $rendu['note'] : ''; ?>" required>
                </div>

                <div class="mb-3">
                    <label for="commentaire" class="form-label">Commentaire d'évaluation</label>
                    <textarea class="form-control" id="commentaire" name="commentaire" 
                            rows="4"><?php echo isset($rendu['commentaire']) ? $rendu['commentaire'] : ''; ?></textarea>
                </div>

                <div class="d-flex justify-content-between">
                    <button type="submit" class="btn btn-primary">Enregistrer l'évaluation</button>
                    <button type="button" class="btn btn-warning" 
                            data-bs-toggle="modal" data-bs-target="#deleguerModal">
                        Déléguer l'évaluation
                    </button>
                </div>
            </form>

            <?php if (!empty($evaluations)): ?>
                <hr>
                <h4>Historique des évaluations</h4>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Évaluateur</th>
                                <th>Note</th>
                                <th>Commentaire</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($evaluations as $eval): ?>
                                <tr>
                                    <td><?php echo date('d/m/Y H:i', strtotime($eval['date_evaluation'])); ?></td>
                                    <td><?php echo htmlspecialchars($eval['evaluateur_login']); ?></td>
                                    <td><?php echo $eval['note'] ? $eval['note'] . '/20' : 'Non noté'; ?></td>
                                    <td><?php echo nl2br(htmlspecialchars($eval['commentaire'])); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Modal de délégation -->
<div class="modal fade" id="deleguerModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Déléguer l'évaluation</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <form method="POST" action="index.php?module=evaluation&action=deleguer">
                    <input type="hidden" name="id_rendu" value="<?php echo $rendu['id_rendu']; ?>">
                    
                    <div class="mb-3">
                        <label for="id_nouvel_evaluateur" class="form-label">Déléguer à</label>
                        <select class="form-select" id="id_nouvel_evaluateur" name="id_nouvel_evaluateur" required>
                            <option value="">Sélectionner un enseignant</option>
                            <?php foreach ($enseignants as $enseignant): ?>
                                <option value="<?php echo $enseignant['id']; ?>">
                                    <?php echo htmlspecialchars($enseignant['prenom'] . ' ' . $enseignant['nom']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <button type="submit" class="btn btn-primary">Déléguer l'évaluation</button>
                </form>
            </div>
        </div>
    </div>
</div>