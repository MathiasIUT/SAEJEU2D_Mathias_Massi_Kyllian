<div class="container mt-4">
    <div class="card">
        <div class="card-header">
            <h2>Évaluations à réaliser</h2>
        </div>
        <div class="card-body">
            <?php if (empty($evaluations)): ?>
                <div class="alert alert-info">
                    Aucune évaluation en attente.
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Projet</th>
                                <th>Groupe</th>
                                <th>Date du rendu</th>
                                <th>Statut</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($evaluations as $evaluation): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($evaluation['projet_titre']); ?></td>
                                    <td><?php echo htmlspecialchars($evaluation['groupe_titre']); ?></td>
                                    <td><?php echo date('d/m/Y H:i', strtotime($evaluation['date_rendu'])); ?></td>
                                    <td>
                                        <?php if ($evaluation['note']): ?>
                                            <span class="badge bg-success">Évalué</span>
                                        <?php else: ?>
                                            <span class="badge bg-warning">En attente</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <a href="index.php?module=evaluation&action=evaluer&id=<?php echo $evaluation['id_rendu']; ?>" 
                                           class="btn btn-sm btn-primary">
                                            <?php echo $evaluation['note'] ? 'Modifier' : 'Évaluer'; ?>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>