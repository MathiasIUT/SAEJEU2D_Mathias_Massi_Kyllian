<?php
$mes_projets = $data['mes_projets'] ?? [];
$mes_rendus = $data['mes_rendus'] ?? [];
$prochains_rendus = $data['prochains_rendus'] ?? [];
?>
<div class="container mt-4">
    <h1 class="mb-4">Tableau de bord étudiant</h1>
    
    <div class="row">
        <div class="col-md-6 mb-4">
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">Mes projets en cours</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Titre</th>
                                    <th>Semestre</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($mes_projets as $projet): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($projet['titre']); ?></td>
                                    <td><?php echo htmlspecialchars($projet['semestre']); ?></td>
                                    <td>
                                        <a href="index.php?module=rendu&action=submit&projet=<?php echo $projet['id_projet']; ?>" 
                                           class="btn btn-sm btn-primary">Soumettre un rendu</a>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-6 mb-4">
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">Mes derniers rendus</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Projet</th>
                                    <th>Date</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($mes_rendus as $rendu): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($rendu['projet_titre']); ?></td>
                                    <td><?php echo date('d/m/Y H:i', strtotime($rendu['date_rendu'])); ?></td>
                                    <td>
                                        <a href="index.php?module=rendu&action=download&id=<?php echo $rendu['id_rendu']; ?>" 
                                           class="btn btn-sm btn-primary">Télécharger</a>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>