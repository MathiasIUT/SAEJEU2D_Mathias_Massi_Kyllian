<div class="container mt-4">
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h2>Ressources du projet</h2>
            <?php if (in_array($_SESSION['user']['role'], ['enseignant', 'admin'])): ?>
                <a href="index.php?module=ressource&action=create" class="btn btn-primary">
                    Ajouter une ressource
                </a>
            <?php endif; ?>
        </div>
        <div class="card-body">
            <?php if (empty($ressources)): ?>
                <div class="alert alert-info">
                    Aucune ressource disponible pour ce projet.
                </div>
            <?php else: ?>
                <div class="row">
                    <?php foreach ($ressources as $ressource): ?>
                        <div class="col-md-6 mb-4">
                            <div class="card h-100 <?php echo $ressource['est_mise_en_avant'] ? 'border-warning' : ''; ?>">
                                <div class="card-header d-flex justify-content-between align-items-center">
                                    <h5 class="mb-0">
                                        <?php if ($ressource['est_mise_en_avant']): ?>
                                            <span class="badge bg-warning me-2">Mise en avant</span>
                                        <?php endif; ?>
                                        <?php echo htmlspecialchars($ressource['titre']); ?>
                                    </h5>
                                    <span class="badge bg-<?php
                                        switch($ressource['type']) {
                                            case 'video': echo 'danger'; break;
                                            case 'pdf': echo 'primary'; break;
                                            case 'code': echo 'success'; break;
                                            default: echo 'info';
                                        }
                                    ?>">
                                        <?php echo ucfirst($ressource['type']); ?>
                                    </span>
                                </div>
                                <div class="card-body">
                                    <?php if ($ressource['description']): ?>
                                        <p class="card-text"><?php echo nl2br(htmlspecialchars($ressource['description'])); ?></p>
                                    <?php endif; ?>
                                    
                                    <div class="d-flex justify-content-between align-items-center mt-3">
                                        <a href="<?php echo htmlspecialchars($ressource['url']); ?>" 
                                           target="_blank" class="btn btn-primary">
                                            Accéder à la ressource
                                        </a>
                                        
                                        <?php if ($est_responsable): ?>
                                            <form method="POST" action="index.php?module=ressource&action=toggle_highlight" class="d-inline">
                                                <input type="hidden" name="id_ressource" value="<?php echo $ressource['id_ressource']; ?>">
                                                <button type="submit" class="btn btn-warning">
                                                    <?php echo $ressource['est_mise_en_avant'] ? 'Retirer mise en avant' : 'Mettre en avant'; ?>
                                                </button>
                                            </form>
                                        <?php endif; ?>
                                        
                                        <?php if ($_SESSION['user']['id'] === $ressource['id_createur'] || $est_responsable): ?>
                                            <button type="button" class="btn btn-danger" 
                                                    onclick="if(confirm('Supprimer cette ressource ?')) 
                                                            window.location.href='index.php?module=ressource&action=delete&id=<?php echo $ressource['id_ressource']; ?>'">
                                                Supprimer
                                            </button>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="card-footer text-muted">
                                    Ajouté par <?php echo htmlspecialchars($ressource['createur_login']); ?>
                                    le <?php echo date('d/m/Y', strtotime($ressource['date_creation'])); ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>