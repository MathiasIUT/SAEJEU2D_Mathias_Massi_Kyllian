<div class="container mt-4">
    <div class="card">
        <div class="card-header">
            <h2>Ajouter une ressource</h2>
        </div>
        <div class="card-body">
            <?php if (isset($error)): ?>
                <div class="alert alert-danger"><?php echo $error; ?></div>
            <?php endif; ?>

            <form method="POST">
                <div class="mb-3">
                    <label for="id_projet" class="form-label">Projet</label>
                    <select class="form-select" id="id_projet" name="id_projet" required>
                        <option value="">Sélectionner un projet</option>
                        <?php foreach ($projets as $projet): ?>
                            <option value="<?php echo $projet['id_projet']; ?>">
                                <?php echo htmlspecialchars($projet['titre']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="mb-3">
                    <label for="titre" class="form-label">Titre de la ressource</label>
                    <input type="text" class="form-control" id="titre" name="titre" required>
                </div>

                <div class="mb-3">
                    <label for="type" class="form-label">Type de ressource</label>
                    <select class="form-select" id="type" name="type" required>
                        <option value="video">Vidéo</option>
                        <option value="pdf">PDF</option>
                        <option value="code">Code source</option>
                        <option value="lien">Lien</option>
                    </select>
                </div>

                <div class="mb-3">
                    <label for="url" class="form-label">URL</label>
                    <input type="url" class="form-control" id="url" name="url" required>
                    <div class="form-text">
                        Exemples d'URLs valides :
                        <ul>
                            <li>Vidéo YouTube : https://www.youtube.com/watch?v=...</li>
                            <li>Document PDF : https://example.com/document.pdf</li>
                            <li>Code source : https://github.com/user/repo</li>
                            <li>Site web : https://www.example.com</li>
                        </ul>
                    </div>
                </div>

                <div class="mb-3">
                    <label for="description" class="form-label">Description</label>
                    <textarea class="form-control" id="description" name="description" rows="3"></textarea>
                </div>

                <div class="d-flex justify-content-between">
                    <button type="submit" class="btn btn-primary">Ajouter la ressource</button>
                    <a href="index.php?module=ressource&action=list" class="btn btn-secondary">Retour à la liste</a>
                </div>
            </form>
        </div>
    </div>
</div>