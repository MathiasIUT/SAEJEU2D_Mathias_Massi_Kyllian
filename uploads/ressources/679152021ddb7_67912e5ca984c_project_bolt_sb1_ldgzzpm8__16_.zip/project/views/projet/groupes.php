<?php
$groupes = $data['groupes'] ?? [];
$etudiants = $data['etudiants'] ?? [];
$id_projet = $data['id_projet'] ?? 0;
?>
<div class="container mt-4">
    <div class="row">
        <div class="col-md-4">
            <div class="card">
                <div class="card-header">
                    <h3>Créer un groupe</h3>
                </div>
                <div class="card-body">
                    <form method="POST">
                        <input type="hidden" name="action" value="creer_groupe">
                        
                        <div class="mb-3">
                            <label for="titre" class="form-label">Titre du groupe</label>
                            <input type="text" class="form-control" id="titre" name="titre" required>
                        </div>
                        
                        <div class="mb-3">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="titre_modifiable" name="titre_modifiable">
                                <label class="form-check-label" for="titre_modifiable">
                                    Titre modifiable par le groupe
                                </label>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="image_modifiable" name="image_modifiable">
                                <label class="form-check-label" for="image_modifiable">
                                    Image modifiable par le groupe
                                </label>
                            </div>
                        </div>
                        
                        <button type="submit" class="btn btn-primary">Créer le groupe</button>
                    </form>
                </div>
            </div>
        </div>
        
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h3>Groupes existants</h3>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Titre</th>
                                    <th>Membres</th>
                                    <th>Options</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($groupes as $groupe): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($groupe['titre']); ?></td>
                                    <td>
                                        <?php echo htmlspecialchars($groupe['membres'] ?? ''); ?>
                                        <?php if ($groupe['nb_etudiants'] < 5): ?>
                                        <form method="POST" class="mt-2">
                                            <input type="hidden" name="action" value="ajouter_etudiant">
                                            <input type="hidden" name="id_groupe" value="<?php echo $groupe['id_groupe']; ?>">
                                            <select name="id_etudiant" class="form-select form-select-sm" required>
                                                <option value="">Ajouter un étudiant</option>
                                                <?php foreach ($etudiants as $etudiant): ?>
                                                <option value="<?php echo $etudiant['id']; ?>">
                                                    <?php echo htmlspecialchars($etudiant['prenom'] . ' ' . $etudiant['nom']); ?>
                                                </option>
                                                <?php endforeach; ?>
                                            </select>
                                            <button type="submit" class="btn btn-sm btn-primary mt-1">Ajouter</button>
                                        </form>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" 
                                                   <?php echo $groupe['titre_modifiable'] ? 'checked' : ''; ?> disabled>
                                            <label class="form-check-label">Titre modifiable</label>
                                        </div>
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" 
                                                   <?php echo $groupe['image_modifiable'] ? 'checked' : ''; ?> disabled>
                                            <label class="form-check-label">Image modifiable</label>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="btn-group">
                                            <button type="button" class="btn btn-sm btn-warning" 
                                                    data-bs-toggle="modal" 
                                                    data-bs-target="#editGroupe<?php echo $groupe['id_groupe']; ?>">
                                                Modifier
                                            </button>
                                            <button type="button" class="btn btn-sm btn-danger" 
                                                    onclick="if(confirm('Supprimer ce groupe ?')) document.getElementById('deleteGroupe<?php echo $groupe['id_groupe']; ?>').submit();">
                                                Supprimer
                                            </button>
                                        </div>
                                        <form id="deleteGroupe<?php echo $groupe['id_groupe']; ?>" 
                                              method="POST" style="display: none;">
                                            <input type="hidden" name="action" value="supprimer_groupe">
                                            <input type="hidden" name="id_groupe" value="<?php echo $groupe['id_groupe']; ?>">
                                        </form>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php foreach ($groupes as $groupe): ?>
<div class="modal fade" id="editGroupe<?php echo $groupe['id_groupe']; ?>" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Modifier le groupe</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <form method="POST">
                    <input type="hidden" name="action" value="modifier_groupe">
                    <input type="hidden" name="id_groupe" value="<?php echo $groupe['id_groupe']; ?>">
                    
                    <div class="mb-3">
                        <label for="titre<?php echo $groupe['id_groupe']; ?>" class="form-label">Titre</label>
                        <input type="text" class="form-control" 
                               id="titre<?php echo $groupe['id_groupe']; ?>" 
                               name="titre" 
                               value="<?php echo htmlspecialchars($groupe['titre']); ?>" 
                               required>
                    </div>
                    
                    <div class="mb-3">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" 
                                   id="titre_modifiable<?php echo $groupe['id_groupe']; ?>" 
                                   name="titre_modifiable"
                                   <?php echo $groupe['titre_modifiable'] ? 'checked' : ''; ?>>
                            <label class="form-check-label" for="titre_modifiable<?php echo $groupe['id_groupe']; ?>">
                                Titre modifiable par le groupe
                            </label>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" 
                                   id="image_modifiable<?php echo $groupe['id_groupe']; ?>" 
                                   name="image_modifiable"
                                   <?php echo $groupe['image_modifiable'] ? 'checked' : ''; ?>>
                            <label class="form-check-label" for="image_modifiable<?php echo $groupe['id_groupe']; ?>">
                                Image modifiable par le groupe
                            </label>
                        </div>
                    </div>
                    
                    <button type="submit" class="btn btn-primary">Enregistrer les modifications</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php endforeach; ?>