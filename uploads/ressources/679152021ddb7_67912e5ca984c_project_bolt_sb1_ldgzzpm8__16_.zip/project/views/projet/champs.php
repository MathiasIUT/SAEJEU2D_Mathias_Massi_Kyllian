<?php
$champs = $data['champs'] ?? [];
$id_projet = $data['id_projet'] ?? 0;
?>
<div class="container mt-4">
    <div class="row">
        <div class="col-md-4">
            <div class="card">
                <div class="card-header">
                    <h3>Ajouter un champ</h3>
                </div>
                <div class="card-body">
                    <form method="POST">
                        <input type="hidden" name="action" value="ajouter_champ">
                        
                        <div class="mb-3">
                            <label for="nom" class="form-label">Nom du champ</label>
                            <input type="text" class="form-control" id="nom" name="nom" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="description" class="form-label">Description</label>
                            <textarea class="form-control" id="description" name="description" rows="3"></textarea>
                        </div>
                        
                        <div class="mb-3">
                            <label for="type" class="form-label">Type</label>
                            <select class="form-select" id="type" name="type" required>
                                <option value="text">Texte</option>
                                <option value="url">URL</option>
                                <option value="file">Fichier</option>
                            </select>
                        </div>
                        
                        <div class="mb-3">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="obligatoire" name="obligatoire">
                                <label class="form-check-label" for="obligatoire">
                                    Champ obligatoire
                                </label>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="modifiable_groupe" name="modifiable_groupe">
                                <label class="form-check-label" for="modifiable_groupe">
                                    Modifiable par le groupe
                                </label>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="ordre" class="form-label">Ordre d'affichage</label>
                            <input type="number" class="form-control" id="ordre" name="ordre" value="0" min="0">
                        </div>
                        
                        <button type="submit" class="btn btn-primary">Ajouter le champ</button>
                    </form>
                </div>
            </div>
        </div>
        
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h3>Champs existants</h3>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Nom</th>
                                    <th>Type</th>
                                    <th>Options</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($champs as $champ): ?>
                                <tr>
                                    <td>
                                        <?php echo htmlspecialchars($champ['nom']); ?>
                                        <?php if ($champ['description']): ?>
                                        <small class="d-block text-muted">
                                            <?php echo htmlspecialchars($champ['description']); ?>
                                        </small>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo htmlspecialchars($champ['type']); ?></td>
                                    <td>
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" 
                                                   <?php echo $champ['obligatoire'] ? 'checked' : ''; ?> disabled>
                                            <label class="form-check-label">Obligatoire</label>
                                        </div>
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" 
                                                   <?php echo $champ['modifiable_groupe'] ? 'checked' : ''; ?> disabled>
                                            <label class="form-check-label">Modifiable par le groupe</label>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="btn-group">
                                            <button type="button" class="btn btn-sm btn-warning" 
                                                    data-bs-toggle="modal" 
                                                    data-bs-target="#editChamp<?php echo $champ['id_champ']; ?>">
                                                Modifier
                                            </button>
                                            <button type="button" class="btn btn-sm btn-danger" 
                                                    onclick="if(confirm('Supprimer ce champ ?')) document.getElementById('deleteChamp<?php echo $champ['id_champ']; ?>').submit();">
                                                Supprimer
                                            </button>
                                        </div>
                                        <form id="deleteChamp<?php echo $champ['id_champ']; ?>" 
                                              method="POST" style="display: none;">
                                            <input type="hidden" name="action" value="supprimer_champ">
                                            <input type="hidden" name="id_champ" value="<?php echo $champ['id_champ']; ?>">
                                        </form>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php foreach ($champs as $champ): ?>
<div class="modal fade" id="editChamp<?php echo $champ['id_champ']; ?>" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Modifier le champ</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div ```
            <div class="modal-body">
                <form method="POST">
                    <input type="hidden" name="action" value="modifier_champ">
                    <input type="hidden" name="id_champ" value="<?php echo $champ['id_champ']; ?>">
                    
                    <div class="mb-3">
                        <label for="nom<?php echo $champ['id_champ']; ?>" class="form-label">Nom</label>
                        <input type="text" class="form-control" 
                               id="nom<?php echo $champ['id_champ']; ?>" 
                               name="nom" 
                               value="<?php echo htmlspecialchars($champ['nom']); ?>" 
                               required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="description<?php echo $champ['id_champ']; ?>" class="form-label">Description</label>
                        <textarea class="form-control" 
                                  id="description<?php echo $champ['id_champ']; ?>" 
                                  name="description" 
                                  rows="3"><?php echo htmlspecialchars($champ['description']); ?></textarea>
                    </div>
                    
                    <div class="mb-3">
                        <label for="type<?php echo $champ['id_champ']; ?>" class="form-label">Type</label>
                        <select class="form-select" 
                                id="type<?php echo $champ['id_champ']; ?>" 
                                name="type" required>
                            <option value="text" <?php echo $champ['type'] === 'text' ? 'selected' : ''; ?>>Texte</option>
                            <option value="url" <?php echo $champ['type'] === 'url' ? 'selected' : ''; ?>>URL</option>
                            <option value="file" <?php echo $champ['type'] === 'file' ? 'selected' : ''; ?>>Fichier</option>
                        </select>
                    </div>
                    
                    <div class="mb-3">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" 
                                   id="obligatoire<?php echo $champ['id_champ']; ?>" 
                                   name="obligatoire"
                                   <?php echo $champ['obligatoire'] ? 'checked' : ''; ?>>
                            <label class="form-check-label" for="obligatoire<?php echo $champ['id_champ']; ?>">
                                Champ obligatoire
                            </label>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" 
                                   id="modifiable_groupe<?php echo $champ['id_champ']; ?>" 
                                   name="modifiable_groupe"
                                   <?php echo $champ['modifiable_groupe'] ? 'checked' : ''; ?>>
                            <label class="form-check-label" for="modifiable_groupe<?php echo $champ['id_champ']; ?>">
                                Modifiable par le groupe
                            </label>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="ordre<?php echo $champ['id_champ']; ?>" class="form-label">Ordre d'affichage</label>
                        <input type="number" class="form-control" 
                               id="ordre<?php echo $champ['id_champ']; ?>" 
                               name="ordre" 
                               value="<?php echo $champ['ordre']; ?>" 
                               min="0">
                    </div>
                    
                    <button type="submit" class="btn btn-primary">Enregistrer les modifications</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php endforeach; ?>