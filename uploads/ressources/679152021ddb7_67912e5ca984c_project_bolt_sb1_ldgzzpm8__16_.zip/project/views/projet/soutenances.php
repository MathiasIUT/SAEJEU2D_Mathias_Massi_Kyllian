<?php
$soutenances = $data['soutenances'] ?? [];
$groupes = $data['groupes'] ?? [];
$id_projet = $data['id_projet'] ?? 0;
?>
<div class="container mt-4">
    <div class="row">
        <div class="col-md-4">
            <div class="card">
                <div class="card-header">
                    <h3>Créer une soutenance</h3>
                </div>
                <div class="card-body">
                    <form method="POST">
                        <input type="hidden" name="action" value="creer_soutenance">
                        
                        <div class="mb-3">
                            <label for="date" class="form-label">Date</label>
                            <input type="date" class="form-control" id="date" name="date" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="duree" class="form-label">Durée (minutes)</label>
                            <input type="number" class="form-control" id="duree" name="duree" 
                                   min="5" step="5" value="20" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="salle" class="form-label">Salle</label>
                            <input type="text" class="form-control" id="salle" name="salle" required>
                        </div>
                        
                        <button type="submit" class="btn btn-primary">Créer la soutenance</button>
                    </form>
                </div>
            </div>
        </div>
        
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h3>Soutenances planifiées</h3>
                </div>
                <div class="card-body">
                    <?php if (empty($soutenances)): ?>
                        <div class="alert alert-info">
                            Aucune soutenance n'a encore été planifiée pour ce projet.
                        </div>
                    <?php else: ?>
                        <?php foreach ($soutenances as $soutenance): ?>
                        <div class="card mb-3">
                            <div class="card-header d-flex justify-content-between align-items-center">
                                <h5 class="mb-0">
                                    Soutenance du <?php echo date('d/m/Y', strtotime($soutenance['date_soutenance'])); ?>
                                    - Salle <?php echo htmlspecialchars($soutenance['salle']); ?>
                                    <small class="text-muted">
                                        (<?php echo $soutenance['duree']; ?> minutes par groupe)
                                    </small>
                                </h5>
                                <form method="POST" class="d-inline">
                                    <input type="hidden" name="action" value="supprimer_soutenance">
                                    <input type="hidden" name="id_soutenance" value="<?php echo $soutenance['id_soutenance']; ?>">
                                    <button type="submit" class="btn btn-sm btn-danger" 
                                            onclick="return confirm('Supprimer cette session de soutenance ?')">
                                        Supprimer
                                    </button>
                                </form>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-6">
                                        <h6>Passages planifiés</h6>
                                        <?php if (empty($soutenance['passages'])): ?>
                                            <p class="text-muted">Aucun passage planifié</p>
                                        <?php else: ?>
                                            <div class="table-responsive">
                                                <table class="table table-sm">
                                                    <thead>
                                                        <tr>
                                                            <th>Heure</th>
                                                            <th>Groupe</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php foreach ($soutenance['passages'] as $passage): ?>
                                                        <tr>
                                                            <td><?php echo $passage['heure_passage']; ?></td>
                                                            <td><?php echo htmlspecialchars($passage['groupe_titre']); ?></td>
                                                        </tr>
                                                        <?php endforeach; ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                    
                                    <div class="col-md-6">
                                        <h6>Planifier un passage</h6>
                                        <form method="POST">
                                            <input type="hidden" name="action" value="planifier_passage">
                                            <input type="hidden" name="id_soutenance" value="<?php echo $soutenance['id_soutenance']; ?>">
                                            
                                            <div class="mb-3">
                                                <label for="groupe<?php echo $soutenance['id_soutenance']; ?>" class="form-label">
                                                    Groupe
                                                </label>
                                                <select class="form-select" 
                                                        id="groupe<?php echo $soutenance['id_soutenance']; ?>" 
                                                        name="id_groupe" required>
                                                    <option value="">Sélectionner un groupe</option>
                                                    <?php foreach ($groupes as $groupe): ?>
                                                    <option value="<?php echo $groupe['id_groupe']; ?>">
                                                        <?php echo htmlspecialchars($groupe['titre']); ?>
                                                    </option>
                                                    <?php endforeach; ?>
                                                </select>
                                            </div>
                                            
                                            <div class="mb-3">
                                                <label for="heure<?php echo $soutenance['id_soutenance']; ?>" class="form-label">
                                                    Heure de passage
                                                </label>
                                                <input type="time" class="form-control" 
                                                       id="heure<?php echo $soutenance['id_soutenance']; ?>" 
                                                       name="heure_passage" required>
                                            </div>
                                            
                                            <button type="submit" class="btn btn-primary">Planifier</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>