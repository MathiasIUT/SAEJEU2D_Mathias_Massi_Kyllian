<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-6 text-center">
            <div class="card">
                <div class="card-body">
                    <h1 class="display-1 text-muted">403</h1>
                    <h2 class="mb-4">Accès refusé</h2>
                    <p class="mb-4">Vous n'avez pas les permissions nécessaires pour accéder à cette page.</p>
                    <a href="index.php" class="btn btn-primary">Retour à l'accueil</a>
                </div>
            </div>
        </div>
    </div>
</div>